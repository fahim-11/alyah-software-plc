<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Content extends Model
{
    use HasFactory;

    protected $fillable = ['title', 'author', 'date', 'body'];

    public function sections()
    {
        return $this->hasMany(Section::class);
    }
}
